import socket, threading
import time
from pathlib import Path

server = socket.socket(socket.AF_INET, socket.SOCK_STREAM) 
server_ip = '0.0.0.0'
server_port = 5402
server.bind((server_ip, server_port))
server.listen(5)

def readall():        
        mypath = Path().absolute()
        print(mypath)
        f = open(str(mypath) + r"\lon.txt", "r")
        lon = f.readlines()
        f.close()
        f = open(str(mypath) + r"\lat.txt", "r")
        lat = f.readlines()
        f.close()
        f = open(str(mypath) + r"\throttle.txt", "r")
        throttle = f.readlines()
        f.close()
        f = open(str(mypath) + r"\rudder.txt", "r")
        rudder = f.readlines()
        f.close()
        return (lon, lat, throttle, rudder)

while True:
        lon, lat, throttle, rudder = readall()
        print ("Wait for new")
        client_socket, client_address = server.accept()
        print ('Connection from: ', client_address)
        data = ""
        while lon and lat and throttle and rudder:
                data = client_socket.recv(4096)
                if "longitude-deg" in data.decode():
                        sendData = lon.pop()
                        print (sendData.encode('ascii'))
                        client_socket.send(sendData.encode('ascii'))
                if "latitude-deg" in data.decode():
                        sendData = lat.pop()
                        print (sendData.encode('ascii'))
                        client_socket.send(sendData.encode('ascii')) 
                if "throttle" in data.decode():
                        sendData = throttle.pop()
                        print (sendData.encode('ascii'))
                        client_socket.send(sendData.encode('ascii')) 
                if "rudder" in data.decode():
                        sendData = rudder.pop()
                        print (sendData.encode('ascii'))
                        client_socket.send(sendData.encode('ascii')) 
        print ("All data recieved")
        #client_socket.close()
        print ("Closed socket")
